package hackaton

object Main extends App {

  println("Hackaton")

}
