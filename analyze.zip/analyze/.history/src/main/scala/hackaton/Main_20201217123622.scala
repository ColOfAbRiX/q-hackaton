package hackaton

import java.io.File;
import org.eclipse.jgit.api._
import org.eclipse.jgit.api.errors._

object Main extends App {

  // 1. Read all commits (with time limit)
  // 2. Find the changed lines and the author
  // 3. Checkout a commit

  Git.open()

  println("Hackaton")
}
