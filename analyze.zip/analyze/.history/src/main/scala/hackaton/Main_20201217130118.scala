package hackaton

import java.io.File;
import org.eclipse.jgit.api._
import org.eclipse.jgit.api.errors._
import scala.jdk.CollectionConverters

object Main extends App {

  // 1. Read all commits (with time limit)
  // 2. Find the changed lines and the author
  // 3. Checkout a commit

  val git  = Git.open(new File("../../../Desktop/metals"))

  val logs = git
    .log()
    .call()
    .asScala

  Git.

  for (log <- logs) {
    println(log.getCommitTime())
    println(log.getAuthorIdent().getName())
    println("")
  }

  //  ----  //

  implicit class ToScala[A](self: java.lang.Iterable[A]) {
    def asScala: List[A] = CollectionConverters.IterableHasAsScala(self).asScala.toList
  }
}
