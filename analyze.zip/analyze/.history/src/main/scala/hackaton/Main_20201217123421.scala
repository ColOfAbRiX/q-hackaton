package hackaton

import java.io.File;
import org.eclipse.jgit.api._
import org.eclipse.jgit.api.errors._

object Main extends App {

  println("Hackaton")
}
